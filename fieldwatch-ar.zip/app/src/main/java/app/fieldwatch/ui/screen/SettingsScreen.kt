package app.fieldwatch.ui.screen

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import app.fieldwatch.ui.component.FieldwatchFilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import app.fieldwatch.ui.component.FieldwatchActionButton
import app.fieldwatch.ui.component.FieldwatchOutlinedField
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import app.fieldwatch.ui.component.FieldwatchSlider
import androidx.compose.material3.Surface
import app.fieldwatch.ui.component.FieldwatchSwitch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.fieldwatch.R
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.fieldwatch.domain.AlertVoiceWhat
import app.fieldwatch.domain.AppSettings
import app.fieldwatch.domain.GnssAlertFloor
import app.fieldwatch.domain.GnssSensitivity
import app.fieldwatch.domain.ScanIntensity
import app.fieldwatch.domain.TakDefaults
import app.fieldwatch.domain.TakFeedStatus
import app.fieldwatch.domain.TakFloodSend
import app.fieldwatch.domain.TakGnssHold
import app.fieldwatch.domain.TakGnssSend
import app.fieldwatch.domain.TakPublish
import app.fieldwatch.domain.TakUdpPreset
import app.fieldwatch.radio.WifiRadio
import app.fieldwatch.ui.NestedTabInsets
import app.fieldwatch.ui.NestedTopBar
import app.fieldwatch.ui.FieldwatchUi
import app.fieldwatch.ui.FieldwatchViewModel
import app.fieldwatch.ui.component.SectionCard
import app.fieldwatch.ui.component.FieldwatchFilterChip
import app.fieldwatch.ui.component.StableCaption
import app.fieldwatch.ui.component.StickyHeight
import java.net.Inet4Address
import java.net.NetworkInterface

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    state: FieldwatchUi,
    vm: FieldwatchViewModel,
    onRadioBookmarks: () -> Unit,
    onScanStatus: () -> Unit,
    onShowLiveTour: () -> Unit = {},
) {
    val context = LocalContext.current
    val settings = state.settings
    val saveSignatures = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> uri?.let(vm::saveSignaturesToUri) }
    val importSignatures = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> uri?.let(vm::importSignaturesFromUri) }
    val saveSettings = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> uri?.let(vm::saveSettingsToUri) }
    val importSettings = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> uri?.let(vm::importSettingsFromUri) }
    var confirmRestore by remember { mutableStateOf(false) }
    val pendingSettingsImport by vm.pendingSettingsImport.collectAsStateWithLifecycle()
    val gnssProfile by vm.gnssProfile.collectAsStateWithLifecycle()
    val gnssCal by vm.gnssCalibration.collectAsStateWithLifecycle()
    val gnssReady = gnssProfile != null
    Scaffold(
        contentWindowInsets = NestedTabInsets,
        topBar = { NestedTopBar("الإعدادات") },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard("المظهر") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("الوضع الليلي", Modifier.weight(1f))
                FieldwatchSwitch(settings.nightMode, { on -> vm.updateSettings { it.copy(nightMode = on) } })
            }
            Text(
                "أحمر على أسود ليبقى الرصد في الظلام خافتاً. لا يتغير سطوع الهاتف.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إبقاء الشاشة مضاءة", Modifier.weight(1f))
                FieldwatchSwitch(settings.keepScreenOn, { on -> vm.updateSettings { it.copy(keepScreenOn = on) } })
            }
            Text(
                "تبقى الشاشة مستيقظة أثناء فتح Fieldwatch ليستمر مسح Bluetooth. يستمر المسح من الإشعار إن غادرت التطبيق. أوقف هذا الخيار عندما تضع الهاتف في جيبك.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("وضع الخصوصية", Modifier.weight(1f))
                FieldwatchSwitch(settings.demoMode, { on -> vm.updateSettings { it.copy(demoMode = on) } })
            }
            Text(
                "يخفي النصف الأخير من كل عنوان MAC على الشاشة وفي تقارير الجلسات. تظهر الإحداثيات مموّهة وتُحذف أسماء الشوارع. تبقى بادئة الشركة المصنّعة. تستمر السجلات والمطابقة والتعقّب في استخدام العنوان والموقع الحقيقيين. يتوقف بث TAK حتى لا تُرسَل هذه البيانات. تظل خريطة المسار تُحمَّل إن كان «أسماء الأماكن والخرائط عبر الإنترنت» مفعّلاً. أوقف هذا الخيار عندما تحتاج إلى العنوان الكامل على الشاشة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }

            SectionCard("المسح") {
            val label = when (settings.intensity) {
                ScanIntensity.SAVER -> "توفير البطارية"
                ScanIntensity.BALANCED -> "متوازن"
                ScanIntensity.PERFORMANCE -> "أداء عالٍ"
            }
            Text("شدة المسح  ·  $label")
            FieldwatchSlider(
                value = settings.intensity.ordinal.toFloat(),
                onValueChange = { v ->
                    val next = ScanIntensity.entries[v.toInt().coerceIn(0, 2)]
                    vm.updateSettings { it.copy(intensity = next) }
                },
                valueRange = 0f..2f,
                steps = 1,
            )
            Text(
                "يقرأ Wi-Fi كل نقاط الوصول دفعة واحدة ثم عليه الانتظار. الأداء العالي يطلب المسح كل 30 ثانية تقريباً، وهذا أسرع ما يسمح به أندرويد. يواصل Bluetooth الاستماع بين تلك المسوح.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            StableCaption(
                state.throttleHint.ifBlank { " " },
                "Wi-Fi ينتظر النظام",
                "Wi-Fi يمسح",
                "Wi-Fi التالي بعد 99 ث",
                " ",
            )

            val lifecycleOwner = LocalLifecycleOwner.current
            var osThrottled by remember { mutableStateOf(WifiRadio.osScanThrottled(context)) }
            var backgroundAllowed by remember { mutableStateOf(isBackgroundUsageAllowed(context)) }
            var unrestricted by remember { mutableStateOf(isIgnoringBatteryOptimizations(context)) }
            var needDevOptions by remember { mutableStateOf(false) }
            var batteryGate by remember { mutableStateOf<BatteryAndroidGate?>(null) }
            DisposableEffect(lifecycleOwner) {
                val obs = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        osThrottled = WifiRadio.osScanThrottled(context)
                        backgroundAllowed = isBackgroundUsageAllowed(context)
                        unrestricted = isIgnoringBatteryOptimizations(context)
                    }
                }
                lifecycleOwner.lifecycle.addObserver(obs)
                onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("مسح أسرع لنقاط وصول Wi-Fi", Modifier.weight(1f))
                FieldwatchSwitch(
                    checked = !osThrottled,
                    onCheckedChange = { needDevOptions = true },
                )
            }
            StableCaption(
                when {
                    Build.VERSION.SDK_INT < 30 ->
                        "هذا الهاتف أقدم من أندرويد 11، لذا لا يستطيع Fieldwatch معرفة هل تقييد مسح Wi-Fi مفعّل. يبقى المفتاح متوقفاً."
                    !osThrottled ->
                        "مفعّل. قائمة جديدة لنقاط الوصول كل 8 ثوانٍ تقريباً. يستهلك بطارية أكثر. هذا يطابق «تقييد مسح Wi-Fi» في خيارات المطوّر."
                    else ->
                        "متوقف. يحدّ أندرويد من مسح Wi-Fi إلى نحو أربع مرات كل دقيقتين. اضغط المفتاح لفتح خيارات المطوّر."
                },
                "هذا الهاتف أقدم من أندرويد 11، لذا لا يستطيع Fieldwatch معرفة هل تقييد مسح Wi-Fi مفعّل. يبقى المفتاح متوقفاً.",
                "مفعّل. قائمة جديدة لنقاط الوصول كل 8 ثوانٍ تقريباً. يستهلك بطارية أكثر. هذا يطابق «تقييد مسح Wi-Fi» في خيارات المطوّر.",
                "متوقف. يحدّ أندرويد من مسح Wi-Fi إلى نحو أربع مرات كل دقيقتين. اضغط المفتاح لفتح خيارات المطوّر.",
            )
            if (needDevOptions) {
                AlertDialog(
                    onDismissRequest = { needDevOptions = false },
                    title = { Text("مسح أسرع لنقاط وصول Wi-Fi") },
                    text = {
                        Text(
                            if (Build.VERSION.SDK_INT < 30) {
                                "هذا الهاتف أقدم من أندرويد 11، لذا لا يستطيع Fieldwatch معرفة هل تقييد مسح Wi-Fi مفعّل. يبقى المسح الأسرع متوقفاً."
                            } else if (osThrottled) {
                                "سيفتح هذا خيارات المطوّر. أوقف «تقييد مسح Wi-Fi». يطابق Fieldwatch ذلك المفتاح عند عودتك."
                            } else {
                                "سيفتح هذا خيارات المطوّر. فعّل «تقييد مسح Wi-Fi» لاستخدام الانتظار العادي. يطابق Fieldwatch ذلك المفتاح عند عودتك."
                            },
                        )
                    },
                    confirmButton = {
                        if (Build.VERSION.SDK_INT >= 30) {
                            TextButton(
                                onClick = {
                                    needDevOptions = false
                                    runCatching {
                                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                                    }
                                },
                            ) { Text("فتح خيارات المطوّر") }
                        } else {
                            TextButton(onClick = { needDevOptions = false }) { Text("حسناً") }
                        }
                    },
                    dismissButton = {
                        if (Build.VERSION.SDK_INT >= 30) {
                            TextButton(onClick = { needDevOptions = false }) { Text("ليس الآن") }
                        }
                    },
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("السماح بالاستخدام في الخلفية", Modifier.weight(1f))
                FieldwatchSwitch(
                    checked = backgroundAllowed,
                    onCheckedChange = { batteryGate = BatteryAndroidGate.BACKGROUND },
                )
            }
            Text(
                "يفتح صفحة بطارية هذا التطبيق. فعّل «السماح بالاستخدام في الخلفية» هناك. إن كان متوقفاً فقد يوقف أندرويد المسح عند مغادرتك.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("بطارية غير مقيّدة", Modifier.weight(1f))
                FieldwatchSwitch(
                    checked = unrestricted,
                    onCheckedChange = { batteryGate = BatteryAndroidGate.UNRESTRICTED },
                )
            }
            Text(
                "يفتح صفحة البطارية نفسها. اختر «غير مقيّد». في بعض الهواتف، ومنها سامسونج، اضغط «السماح بالاستخدام في الخلفية» أولاً ثم اختر «غير مقيّد».",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (batteryGate != null) {
                val background = batteryGate == BatteryAndroidGate.BACKGROUND
                AlertDialog(
                    onDismissRequest = { batteryGate = null },
                    title = {
                        Text(if (background) "السماح بالاستخدام في الخلفية" else "بطارية غير مقيّدة")
                    },
                    text = {
                        Text(
                            if (background) {
                                "سيفتح هذا صفحة بطارية Fieldwatch. فعّل «السماح بالاستخدام في الخلفية». يطابقه Fieldwatch عند عودتك."
                            } else {
                                "اختر «غير مقيّد». في بعض الهواتف، ومنها سامسونج، اضغط عبارة «السماح بالاستخدام في الخلفية» ثم اختر «غير مقيّد». يطابقه Fieldwatch عند عودتك."
                            },
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                val gate = batteryGate
                                batteryGate = null
                                openAppBatteryPage(
                                    context,
                                    highlightBackground = gate == BatteryAndroidGate.BACKGROUND,
                                )
                            },
                        ) { Text("فتح إعدادات أندرويد") }
                    },
                    dismissButton = {
                        TextButton(onClick = { batteryGate = null }) { Text("ليس الآن") }
                    },
                )
            }
            }

            SectionCard("قائمة المراقبة") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("تنبيهات قائمة المراقبة", Modifier.weight(1f))
                FieldwatchSwitch(settings.alertsEnabled, { on -> vm.updateSettings { it.copy(alertsEnabled = on) } })
            }
            Text(
                "صفير وصوت ووميض وقفزة عند ظهور بصمة مضافة للمراقبة أو مصدر مسمّى. إن كان متوقفاً تبقى الإشارات المرجعية ويظل Fieldwatch صامتاً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val radioWatchN = state.watchlist.count { it.deviceKey != null }
            FieldwatchActionButton(
                onClick = onRadioBookmarks,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("المصادر المسمّاة ($radioWatchN)") }
            Text(
                "اسم لعنوان MAC واحد. التنبيه اختياري. «المرشّحات ← المصادر المسمّاة» تعرضها في المباشر. تبقى مراقبات البصمات في تبويب البصمات.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("صفير عند بصمة مراقَبة", Modifier.weight(1f))
                FieldwatchSwitch(
                    settings.alertBeep,
                    { on -> vm.updateSettings { it.copy(alertBeep = on) } },
                    enabled = settings.alertsEnabled,
                )
            }
            Text(
                "نبرتان قصيرتان على مستوى صوت الوسائط عندما يظهر مصدر مراقَب أول مرة أو يعود بعد مغادرته. لا تتكرر ما دام المصدر ظاهراً. يمكنك استخدام الصفير أو الصوت أو كليهما. ارفع صوت الوسائط إن لم تسمع شيئاً ثم اضغط «اختبار التنبيه».",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("صوت عند بصمة مراقَبة", Modifier.weight(1f))
                FieldwatchSwitch(
                    settings.alertVoice,
                    { on -> vm.updateSettings { it.copy(alertVoice = on) } },
                    enabled = settings.alertsEnabled,
                )
            }
            Text(
                "ينطق المراقبة بمستوى الصوت نفسه للصفير. يمكنك استخدام الصفير أو الصوت أو كليهما. يُتخطى الرصد الثاني إن كان Fieldwatch ينطق بالفعل. وإن لم يوجد محرك نطق يبقى الصفير يعمل إن كان مفعّلاً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text("ماذا يُنطق", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AlertVoiceWhat.entries.forEach { item ->
                    FieldwatchFilterChip(
                        selected = settings.alertVoiceWhat == item,
                        onClick = { vm.updateSettings { it.copy(alertVoiceWhat = item) } },
                        enabled = settings.alertsEnabled && settings.alertVoice,
                        label = { Text(item.label()) },
                    )
                }
            }
            Text(
                "الفئة هي المجموعة في المباشر، مثل أجهزة التتبع أو الصوتيات. البصمة هي اسم الكتالوج، مثل Apple AirTags. «الفئة + البصمة» ينطق الاثنين. المصدر المسمّى مع تفعيل التنبيه ينطق دائماً الاسم الذي أعطيته له.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FieldwatchActionButton(
                onClick = vm::testWatchBeep,
                modifier = Modifier.fillMaxWidth(),
                enabled = settings.alertsEnabled && (settings.alertBeep || settings.alertVoice),
            ) { Text("اختبار التنبيه") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("القفز إلى رصد مراقَب جديد", Modifier.weight(1f))
                FieldwatchSwitch(
                    settings.snapToBeep,
                    { on -> vm.updateSettings { it.copy(snapToBeep = on) } },
                    enabled = settings.alertsEnabled && (settings.alertBeep || settings.alertVoice),
                )
            }
            Text(
                "يتمرّر المباشر إلى المصدر المراقَب الجديد لترى الوميض. أوقف هذا الخيار إن لم تُرد أن تتحرك القائمة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إشعار النظام", Modifier.weight(1f))
                FieldwatchSwitch(
                    settings.alertShade,
                    { on -> vm.updateSettings { it.copy(alertShade = on) } },
                    enabled = settings.alertsEnabled,
                )
            }
            Text(
                "إشعار صامت عند ظهور مصدر مراقَب. يكفي الصفير والوميض في معظم الجلسات.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }

            SectionCard("الموقع") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("وسم الرصد بـ GPS", Modifier.weight(1f))
                FieldwatchSwitch(settings.tagLocation, { on -> vm.updateSettings { it.copy(tagLocation = on) } })
            }
            Text(
                "يختم موقع هذا الهاتف على كل رصد: تفاصيل المباشر، والتحرك معك، وملخص الرصد، وصفوف السجل الجديدة. " +
                    "هذا هو مكانك أنت، وليس موقعاً صادراً من المصدر الآخر. " +
                    "استخدم الموقع عالي الدقة وإلا يبقى المسار فارغاً. " +
                    "دبابيس TAK «سُمع هنا» تحتاج إلى هذا. يستخدم Remote ID الإحداثيات الموجودة في الإعلان. " +
                    "أوقف هذا الخيار لإبقاء موقعك خارج السجلات.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("أسماء الأماكن والخرائط عبر الإنترنت", Modifier.weight(1f))
                FieldwatchSwitch(settings.onlineLookup, { on -> vm.updateSettings { it.copy(onlineLookup = on) } })
            }
            Text(
                "مع الإنترنت يحوّل ملخص الرصد الإحداثيات إلى شارع ومدينة، ويحمّل «التقارير ← المسار» خريطة تحت الأثر. " +
                    "لا يُرسَل شيء إلى أي خادم تابع لـ Fieldwatch. " +
                    "دون اتصال يُبقي ملخص الرصد الإحداثيات ويبقى المسار أثراً بسيطاً. " +
                    "أوقف هذا الخيار لإخراج الشوارع والخريطة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }

            SectionCard("تشويش GNSS") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("فحص تشويش GNSS", Modifier.weight(1f))
                FieldwatchSwitch(
                    checked = settings.gnssMonitor && gnssReady,
                    onCheckedChange = { on ->
                        if (gnssReady) vm.updateSettings { it.copy(gnssMonitor = on) }
                    },
                    enabled = gnssReady && !gnssCal.running,
                )
            }
            Text(
                "يكشف التشويش والانتحال على أقمار GNSS (GPS) الصناعية. " +
                    "قد يحدث التشويش أيضاً بسبب أجهزة إلكترونية قريبة أخرى مثل راوترات Wi-Fi. " +
                    "لا يستطيع Fieldwatch معرفة المصدر ولا المسافة. " +
                    "قد يفوتك رصد كان جارياً بالفعل عند بدء الفحص. " +
                    "عند الرصد تظهر نافذة منبثقة. بعد إغلاقها يبقى خط أحمر في المباشر حتى ينتهي.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (!gnssReady) {
                Text(
                    "عايِر هذا الهاتف قبل تفعيل الفحص.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            FieldwatchActionButton(
                onClick = { if (gnssCal.running) vm.stopGnssCalibration() else vm.startGnssCalibration() },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (gnssCal.running) "إيقاف المعايرة" else "معايرة هذا الهاتف") }
            Text(
                "قف في الخارج وابقَ ثابتاً وابتعد عن الراوتر. يستغرق هذا نحو دقيقة. " +
                    "تبقى النتيجة على هذا الهاتف حتى تعاير مجدداً. وليست جزءاً من «تصدير الإعدادات».",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (gnssCal.running) {
                Text(
                    "جارٍ المعايرة… متبقٍّ ${gnssCal.leftSec} ث",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (gnssCal.rejection.isNotBlank()) {
                Text(
                    gnssCal.rejection,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            gnssProfile?.let { profile ->
                Text(
                    profile.summary(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    "تمت المعايرة ${profile.calibratedLabel()}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text("الحساسية", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GnssSensitivity.entries.forEach { item ->
                    FieldwatchFilterChip(
                        selected = settings.gnssSensitivity == item,
                        onClick = { vm.updateSettings { it.copy(gnssSensitivity = item) } },
                        label = { Text(item.label()) },
                    )
                }
            }
            Text(
                "«منخفضة» تنتظر هبوطاً أعمق. «عالية» تنبّه عند هبوط أصغر، ومنه ما تسببه بعض الراوترات.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text("التنبيه من", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GnssAlertFloor.entries.forEach { item ->
                    FieldwatchFilterChip(
                        selected = settings.gnssAlertFloor == item,
                        onClick = { vm.updateSettings { it.copy(gnssAlertFloor = item) } },
                        label = { Text(item.label()) },
                    )
                }
            }
            Text(
                "تبدأ النافذة المنبثقة والخط الأحمر والصفير والصوت عند هذا المستوى. يظهر الرصد الأضعف في التشخيص وفي تقرير الجلسة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("فحوص الانتحال", Modifier.weight(1f))
                FieldwatchSwitch(settings.gnssSpoofChecks, { on -> vm.updateSettings { it.copy(gnssSpoofChecks = on) } })
            }
            Text(
                "يراقب هبوط الكسب بينما تثبت الإشارة أو ترتفع. ويُحتسب عدم تطابق الساعة أو الموقع مع ذلك، أو مع عدم تطابق آخر. عدم تطابق واحد وحده لا يُحذّر. وقد يتجاوز منتحلٌ حذر هذه الفحوص.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("صفير", Modifier.weight(1f))
                FieldwatchSwitch(settings.gnssBeep, { on -> vm.updateSettings { it.copy(gnssBeep = on) } })
            }
            Text(
                "النبرة نفسها لرصد قائمة المراقبة، على مستوى صوت الوسائط. تظهر النافذة المنبثقة والخط الأحمر حتى لو كان هذا متوقفاً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("صوت", Modifier.weight(1f))
                FieldwatchSwitch(settings.gnssVoice, { on -> vm.updateSettings { it.copy(gnssVoice = on) } })
            }
            Text(
                "ينطق «تشويش GPS محتمل» أو «انتحال GPS محتمل». ينطق مجدداً فقط عندما يرتفع المستوى. يستخدم مستوى صوت الوسائط. منفصل عن مفتاح صوت قائمة المراقبة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إشعار النظام", Modifier.weight(1f))
                FieldwatchSwitch(settings.gnssShade, { on -> vm.updateSettings { it.copy(gnssShade = on) } })
            }
            Text(
                "إشعار صامت لهذا التحذير. تظهر النافذة المنبثقة والخط الأحمر حتى لو كان هذا متوقفاً. منفصل عن مفتاح قائمة المراقبة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("التتبع الكامل", Modifier.weight(1f))
                FieldwatchSwitch(settings.gnssFullTracking, { on -> vm.updateSettings { it.copy(gnssFullTracking = on) } })
            }
            Text(
                "يبقي مستقبل GPS مستيقظاً بدل تركه يستريح. يستهلك بطارية أكثر. أندرويد 12 وما بعده. الهواتف الأقدم تتجاهل هذا.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("فحص الخفوت المتزامن", Modifier.weight(1f))
                FieldwatchSwitch(settings.gnssCorrelation, { on -> vm.updateSettings { it.copy(gnssCorrelation = on) } })
            }
            Text(
                "يراقب خفوت الأقمار الصناعية في الوقت نفسه. قد تسببه يد أو جيب أو ركوب سيارة. اتركه متوقفاً إلا إذا كنت تختبره.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("عكس الكسب", Modifier.weight(1f))
                FieldwatchSwitch(settings.gnssInvertAgc, { on -> vm.updateSettings { it.copy(gnssInvertAgc = on) } })
            }
            Text(
                "تُبلّغ بعض الهواتف عن الكسب معكوساً. فعّل هذا فقط إن كان راوتر Wi-Fi يرفع رقم AGC في التشخيص.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }

            SectionCard("TAK / CoT") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("بث TAK / CoT", Modifier.weight(1f))
                FieldwatchSwitch(settings.takEnabled, { on -> vm.updateSettings { it.copy(takEnabled = on) } })
            }
            Text(
                "يرسل علامات الخريطة إلى ATAK أو WinTAK أو iTAK. " +
                    "تُثبَّت المصادر التي تسمعها عند موقع GPS لهذا الهاتف، في أعلى نقطة صوتاً، وتُوسم بـ (هنا). " +
                    "الابتعاد لا يحرّك الدبوس. أما رصد أقوى فيحرّكه. " +
                    "طائرات Remote ID تستخدم الإحداثيات الموجودة في الإعلان. وموقع المشغّل دبوس ثانٍ: نقطة الإقلاع أو الطيار أو نقطة ثابتة. " +
                    "المصدر الذي يغادر يحتفظ باسمه طوال «مدة بقاء النقطة». اضغط علامة لرؤية الاسم وMAC والإشارة. " +
                    "هذا ليس تحديداً للاتجاه. وضع الخصوصية يوقف البث.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (settings.takEnabled && settings.demoMode) {
                Text(
                    "وضع الخصوصية مفعّل، لذا البث متوقف. أوقف وضع الخصوصية لإرسال العلامات.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (settings.takEnabled) {
                TakFeedSettings(settings, vm, state.takStatus)
            }
            }

            SectionCard("التسجيل") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("كتابة عمليات الرصد على القرص", Modifier.weight(1f))
                FieldwatchSwitch(settings.loggingEnabled, { on -> vm.updateSettings { it.copy(loggingEnabled = on) } })
            }
            StableCaption(
                if (settings.loggingEnabled) {
                    "التسجيل مفعّل. تُضاف عمليات الرصد الجديدة إلى الملف."
                } else {
                    "التسجيل متوقف. يستمر المسح. لا يُكتب أي جديد حتى تفعّل هذا."
                },
                "التسجيل مفعّل. تُضاف عمليات الرصد الجديدة إلى الملف.",
                "التسجيل متوقف. يستمر المسح. لا يُكتب أي جديد حتى تفعّل هذا.",
            )
            Text(
                "الملف على القرص يحوي رصداً واحداً في كل سطر. «التقارير ← السجل» يمكنه مشاركة أو حفظ CSV أو JSON أو GPX أو KML أو WiGLE.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            var rotateDrag by remember { mutableIntStateOf(settings.logRotateKb) }
            var rotateDragging by remember { mutableStateOf(false) }
            LaunchedEffect(settings.logRotateKb) {
                if (!rotateDragging) rotateDrag = settings.logRotateKb
            }
            Text("تدوير عند $rotateDrag KB")
            FieldwatchSlider(
                value = rotateDrag.toFloat(),
                onValueChange = {
                    rotateDragging = true
                    rotateDrag = it.toInt().coerceIn(128, 4096)
                },
                onValueChangeFinished = {
                    vm.updateSettings { s -> s.copy(logRotateKb = rotateDrag) }
                    rotateDragging = false
                },
                valueRange = 128f..4096f,
            )
            var staleDrag by remember { mutableIntStateOf(settings.staleSec) }
            var staleDragging by remember { mutableStateOf(false) }
            LaunchedEffect(settings.staleSec) {
                if (!staleDragging) staleDrag = settings.staleSec
            }
            Text("يصبح قديماً بعد ${staleDrag} ث")
            FieldwatchSlider(
                value = staleDrag.toFloat(),
                onValueChange = {
                    staleDragging = true
                    staleDrag = it.toInt().coerceIn(15, 180)
                },
                onValueChangeFinished = {
                    vm.updateSettings { s -> s.copy(staleSec = staleDrag) }
                    staleDragging = false
                },
                valueRange = 15f..180f,
            )
            StickyHeight("log-stats") {
                Text(
                    "${state.logLines} سطر في هذه الجلسة  ·  ${vm.logBytes() / 1024} KB على القرص. " +
                        "المشاركة والحفظ و«إعادة ضبط / مسح السجل» في تبويب التقارير.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            }

            SectionCard("البصمات") {
            Text(
                "«التصدير» يشارك الكتالوج، بما فيه البصمات التي أضفتها. «الاستيراد» يضيف صفوفاً ولا يحذف أي شيء. «التحديث من GitHub» يجدّد البصمات الأساسية ويترك بصماتك وإشاراتك المرجعية وإعداداتك. يحتاج إلى الإنترنت. «استعادة الافتراضيات» تحذف البصمات التي أضفتها.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FieldwatchActionButton(
                onClick = vm::startSignatureShare,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("تصدير البصمات") }
            FieldwatchActionButton(
                onClick = { saveSignatures.launch(vm.suggestedSignaturesName()) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("حفظ البصمات في بطاقة SD / التخزين…") }
            FieldwatchActionButton(
                onClick = {
                    importSignatures.launch(arrayOf("application/json", "text/plain", "*/*"))
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("استيراد البصمات…") }
            FieldwatchActionButton(
                onClick = vm::updateStockCatalogFromGitHub,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("تحديث الكتالوج الأساسي من GitHub") }

            FieldwatchActionButton(
                onClick = { confirmRestore = true },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("استعادة البصمات والإعدادات المسبقة الافتراضية")
            }
            }

            SectionCard("نسخة احتياطية للإعدادات") {
            Text(
                "تحفظ المفاتيح والمرشّحات والإعدادات المسبقة والمصادر المسمّاة ومراقبات البصمات. لا تحفظ الكتالوج ولا السجلات. " +
                    "الكتالوج يُحفظ بـ «تصدير البصمات» أعلاه. «الاستيراد» يستبدل هذه العناصر على هذا الهاتف ويترك الكتالوج. " +
                    "يسأل Fieldwatch قبل أن يشغّل ملف بث TAK أو يغيّر وجهة إرساله.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FieldwatchActionButton(
                onClick = vm::startSettingsShare,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("تصدير الإعدادات") }
            FieldwatchActionButton(
                onClick = { saveSettings.launch(vm.suggestedSettingsName()) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("حفظ الإعدادات في بطاقة SD / التخزين…") }
            FieldwatchActionButton(
                onClick = {
                    importSettings.launch(arrayOf("application/json", "text/plain", "*/*"))
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("استيراد الإعدادات…") }
            }

            FieldwatchActionButton(
                onClick = onShowLiveTour,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("عرض جولة المباشر") }
            Text(
                "يعرض جولة المباشر مجدداً: العرض والإيقاف المؤقت والمرشّحات والبصمات والتقارير والإعدادات.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FieldwatchActionButton(
                onClick = onScanStatus,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("التشخيص") }
            Text(
                "الهاتف وإصدار أندرويد ومفاتيح المسح وهل Wi-Fi وBluetooth والموقع مفعّلة. «نسخ» يلصق ذلك في بلاغ. تُستثنى أسماء الشبكات وإحداثيات GPS.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Text(
                "Fieldwatch ${app.fieldwatch.BuildConfig.VERSION_NAME}  ·  الكتالوج ${state.catalogVersion}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Wi-Fi وBluetooth فقط. لا يُظهر أندرويد الهواتف المتصلة بنقطة وصول فحسب. يرى Fieldwatch نقاط الوصول ومعلِنات Bluetooth.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val footerLifecycle = LocalLifecycleOwner.current
            var ipv4 by remember { mutableStateOf(localIpv4Addresses()) }
            DisposableEffect(footerLifecycle) {
                val obs = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) ipv4 = localIpv4Addresses()
                }
                footerLifecycle.lifecycle.addObserver(obs)
                onDispose { footerLifecycle.lifecycle.removeObserver(obs) }
            }
            Text(
                if (ipv4.isEmpty()) {
                    "IPv4 لهذا الهاتف  ·  لا يوجد"
                } else {
                    "IPv4 لهذا الهاتف  ·  ${ipv4.joinToString("  ·  ")}"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(24.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            CreditFooter()
        }
    }
    pendingSettingsImport?.let { pending ->
        AlertDialog(
            onDismissRequest = vm::dismissPendingSettingsImport,
            title = { Text("استيراد الإعدادات؟") },
            text = { Text(pending.message) },
            confirmButton = {
                TextButton(onClick = vm::confirmPendingSettingsImport) { Text("استيراد") }
            },
            dismissButton = {
                TextButton(onClick = vm::dismissPendingSettingsImport) { Text("إلغاء") }
            },
        )
    }
    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text("استعادة الافتراضيات؟") },
            text = {
                Text(
                    "تستبدل الكتالوج الأساسي والألوان والإشارات المرجعية الأساسية والمرشّحات الأساسية والمفاتيح الافتراضية. " +
                        "تُحذف البصمات والمرشّحات التي أضفتها. صدّرها أولاً إن أردت نسخة احتياطية. " +
                        "لا يمكن التراجع عن هذا.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmRestore = false
                        vm.restoreDefaults()
                    },
                ) { Text("استعادة") }
            },
            dismissButton = {
                TextButton(onClick = { confirmRestore = false }) { Text("إلغاء") }
            },
        )
    }
}

@Composable
private fun CreditFooter() {
    val context = LocalContext.current
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            "Copyright (c) 2026 Off Grid Pete LLC. All rights reserved.",
            style = MaterialTheme.typography.labelSmall,
            color = muted,
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SocialChip(
                icon = R.drawable.ic_instagram,
                label = "@OffGridPete",
                tint = muted,
                onClick = { openUrl(context, "https://instagram.com/OffGridPete") },
            )
            SocialChip(
                icon = R.drawable.ic_x,
                label = "@OGridPete",
                tint = muted,
                onClick = { openUrl(context, "https://x.com/OGridPete") },
            )
        }
    }
}

@Composable
private fun SocialChip(
    icon: Int,
    label: String,
    tint: Color,
    onClick: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(99.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
        modifier = Modifier.clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                painter = painterResource(icon),
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(14.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = tint)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TakFeedSettings(settings: AppSettings, vm: FieldwatchViewModel, status: TakFeedStatus) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var hostText by remember { mutableStateOf(settings.takHost) }
    var portText by remember { mutableStateOf(settings.takPort.toString()) }
    LaunchedEffect(settings.takHost) { hostText = settings.takHost }
    LaunchedEffect(settings.takPort) { portText = settings.takPort.toString() }
    val preset = TakPublish.udpPreset(settings.takHost, settings.takPort)
    Text("الوجهة", style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FieldwatchFilterChip(
            selected = preset == TakUdpPreset.THIS_PHONE,
            onClick = {
                val (host, port) = TakPublish.applyPreset(TakUdpPreset.THIS_PHONE)
                vm.updateSettings { it.copy(takHost = host, takPort = port) }
            },
            enabled = !settings.demoMode,
            label = { Text("هذا الهاتف") },
        )
        FieldwatchFilterChip(
            selected = preset == TakUdpPreset.LAN_MULTICAST,
            onClick = {
                val (host, port) = TakPublish.applyPreset(TakUdpPreset.LAN_MULTICAST)
                vm.updateSettings { it.copy(takHost = host, takPort = port) }
            },
            enabled = !settings.demoMode,
            label = { Text("بث LAN متعدد") },
        )
        FieldwatchFilterChip(
            selected = preset == TakUdpPreset.CUSTOM,
            onClick = {
                if (preset != TakUdpPreset.CUSTOM) {
                    val (host, port) = TakPublish.applyPreset(TakUdpPreset.CUSTOM)
                    vm.updateSettings { it.copy(takHost = host, takPort = port) }
                }
            },
            enabled = !settings.demoMode,
            label = { Text("مخصّص") },
        )
    }
    Text(
        "«هذا الهاتف» يعني ATAK على هذا الجهاز نفسه، عند ${TakDefaults.LOOPBACK}:${TakDefaults.PORT}. " +
            "«بث LAN متعدد» هو ${TakDefaults.SA_HOST}:${TakDefaults.SA_PORT}، لتطبيقات ATAK الأخرى على شبكة Wi-Fi هذه. " +
            "«مخصّص» عنوان واحد. UDP فقط. خادم TAK على TCP 8087 ليس هذا البث. " +
            "إن لم تُظهر «هذا الهاتف» أي دبابيس فاستخدم «مخصّص» مع عنوان Wi-Fi في أسفل الإعدادات والمنفذ ${TakDefaults.PORT}.",
        style = MaterialTheme.typography.bodySmall,
        color = muted,
    )
    FieldwatchOutlinedField(
        value = hostText,
        onValueChange = { value ->
            hostText = value
            val trimmed = value.trim()
            if (trimmed.isNotEmpty()) {
                vm.updateSettings { it.copy(takHost = trimmed) }
            }
        },
        label = "المضيف",
        placeholder = TakDefaults.HOST,
        enabled = !settings.demoMode,
    )
    FieldwatchOutlinedField(
        value = portText,
        onValueChange = { value ->
            val filtered = value.filter { it.isDigit() }.take(5)
            portText = filtered
            filtered.toIntOrNull()?.let { n ->
                if (n in 1..65_535) {
                    vm.updateSettings { it.copy(takPort = n) }
                }
            }
        },
        label = "المنفذ",
        placeholder = TakDefaults.PORT.toString(),
        supportingText = "UDP. هذا الهاتف يستخدم ${TakDefaults.PORT}. بث LAN المتعدد يستخدم ${TakDefaults.SA_PORT}. وليس TCP 8087.",
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        enabled = !settings.demoMode,
    )
    Text(takStatusLine(status), style = MaterialTheme.typography.bodySmall, color = muted)
    Text("ما يُرسَل", style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FieldwatchFilterChip(
            selected = settings.takAttention,
            onClick = { vm.updateSettings { it.copy(takAttention = !it.takAttention) } },
            enabled = !settings.demoMode,
            label = { Text("انتباه إضافي") },
        )
        FieldwatchFilterChip(
            selected = settings.takPayloadFix,
            onClick = { vm.updateSettings { it.copy(takPayloadFix = !it.takPayloadFix) } },
            enabled = !settings.demoMode,
            label = { Text("موقع الحمولة") },
        )
        FieldwatchFilterChip(
            selected = settings.takWatchlist,
            onClick = { vm.updateSettings { it.copy(takWatchlist = !it.takWatchlist) } },
            enabled = !settings.demoMode,
            label = { Text("قائمة المراقبة") },
        )
        FieldwatchFilterChip(
            selected = settings.takAllSignatures,
            onClick = { vm.updateSettings { it.copy(takAllSignatures = !it.takAllSignatures) } },
            enabled = !settings.demoMode,
            label = { Text("كل البصمات") },
        )
    }
    Text(
        "فعّل أي مجموعة. «انتباه إضافي» يرسل الكاميرات المحمولة على الجسم والنظارات ومسجّلات الصوت وأدوات اختبار الاختراق ونقاط وصول السلامة العامة. " +
            "«موقع الحمولة» يرسل Remote ID وأي مصدر يعلن إحداثياته بنفسه. " +
            "«قائمة المراقبة» ترسل البصمات ذات الإشارة المرجعية والمصادر المسمّاة مع تفعيل التنبيه. " +
            "«كل البصمات» ترسل كل مصدر موسوم، وهذا مزعج في الزحام. " +
            "المصادر غير المطابقة لا تُرسَل أبداً. يحتاج الدبوس إلى إحداثيات، من الإعلان أو من «وسم الرصد بـ GPS».",
        style = MaterialTheme.typography.bodySmall,
        color = muted,
    )
    Text("مدة بقاء النقطة", style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TakGnssHold.entries.forEach { item ->
            FieldwatchFilterChip(
                selected = settings.takRadioHold == item,
                onClick = { vm.updateSettings { it.copy(takRadioHold = item) } },
                enabled = !settings.demoMode,
                label = { Text(item.label()) },
            )
        }
    }
    Text(
        "بعد مغادرة المصدر تحتفظ النقطة باسمها هذه المدة. يبدأ الوقت عند مغادرته. " +
            "«حتى الحذف» تبقى حتى يُوقف البث. " +
            "تبقى علامة Fieldwatch لهذا الهاتف نحو دقيقتين.",
        style = MaterialTheme.typography.bodySmall,
        color = muted,
    )
    Text("GNSS", style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TakGnssSend.entries.forEach { item ->
            FieldwatchFilterChip(
                selected = settings.takGnss == item,
                onClick = { vm.updateSettings { it.copy(takGnss = item) } },
                enabled = !settings.demoMode,
                label = { Text(item.label()) },
            )
        }
    }
    Text(
        "علامة على الخريطة حيث كان هذا الهاتف، وخط على علامة Fieldwatch لهذا الهاتف. " +
            "الرصد القصير دبوس. والرصد المستمر أثناء تحرك الهاتف يصبح قطعاً ناقصاً من البداية إلى آخر مكان سُمع فيه، بعرض نصف طوله. " +
            "العلامة لا تحدد مكان السبب. " +
            "«إيقاف» لا يرسل شيئاً. «أثناء التنبيه» يرسل أثناء رصد عند «التنبيه من» أو فوقه. " +
            "«خط أحمر» يبقي الخط أيضاً 10 دقائق بعده. ويتوقف القطع الناقص عن النمو عند انتهاء الرصد. " +
            "أي رصد يرسل أيضاً رصداً «منخفضاً» لا يُظهر الخط الأحمر أبداً. " +
            "يحتاج هذا الهاتف إلى تحديد موقع GPS.",
        style = MaterialTheme.typography.bodySmall,
        color = muted,
    )
    Text("مدة بقاء العلامة", style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TakGnssHold.entries.forEach { item ->
            FieldwatchFilterChip(
                selected = settings.takGnssHold == item,
                onClick = { vm.updateSettings { it.copy(takGnssHold = item) } },
                enabled = !settings.demoMode && settings.takGnss != TakGnssSend.OFF,
                label = { Text(item.label()) },
            )
        }
    }
    Text(
        "يبدأ الوقت عند آخر تحديث. «حتى الحذف» تبقى حتى يُضبط GNSS على «إيقاف».",
        style = MaterialTheme.typography.bodySmall,
        color = muted,
    )
    Text("الإغراق", style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TakFloodSend.entries.forEach { item ->
            FieldwatchFilterChip(
                selected = settings.takFlood == item,
                onClick = { vm.updateSettings { it.copy(takFlood = item) } },
                enabled = !settings.demoMode,
                label = { Text(item.label()) },
            )
        }
    }
    Text(
        "يضيف ملاحظة إلى علامة Fieldwatch لهذا الهاتف عند اكتشاف إغراق، حتى ينتهي. وليس دبوساً مستقلاً. " +
            "لا يغيّر هذا الخط الأحمر في المباشر. قد يسببه متجر ممتلئ بمصادر تعلن الاقتران. " +
            "لا تقول الملاحظة إنه مصدر واحد، ولا تسمّي أداة. يحتاج هذا الهاتف إلى تحديد موقع GPS.",
        style = MaterialTheme.typography.bodySmall,
        color = muted,
    )
}

private fun takStatusLine(status: TakFeedStatus): String {
    if (status.paused) return "حالة البث  ·  متوقف (وضع الخصوصية)"
    if (status.error != null) {
        val whenAt = takStatusWhen(status.at)
        return "حالة البث  ·  خطأ: ${status.error}" + if (whenAt.isNotEmpty()) "  ·  $whenAt" else ""
    }
    if (status.at <= 0L) {
        return "حالة البث  ·  لم يُرسَل شيء بعد في هذه الجلسة"
    }
    val bits = ArrayList<String>(5)
    bits += "على البث ${status.onFeed}"
    bits += "أُرسل ${status.sent}"
    if (status.gone > 0) {
        bits += if (status.gone == 1) "1 غادر" else "${status.gone} غادر"
    }
    if (status.dest.isNotBlank()) bits += status.dest
    val whenAt = takStatusWhen(status.at)
    if (whenAt.isNotEmpty()) bits += whenAt
    val head = "حالة البث  ·  ${bits.joinToString("  ·  ")}"
    return if (status.detail.isNotBlank() && status.sent == 0 && status.gone == 0) {
        "$head  ·  ${status.detail}"
    } else {
        head
    }
}

private fun takStatusWhen(at: Long): String {
    if (at <= 0L) return ""
    return java.time.Instant.ofEpochMilli(at)
        .atZone(java.time.ZoneId.systemDefault())
        .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
}

private fun localIpv4Addresses(): List<String> {
    val found = LinkedHashSet<String>()
    val nifs = runCatching {
        java.util.Collections.list(NetworkInterface.getNetworkInterfaces())
    }.getOrDefault(emptyList())
    for (nif in nifs) {
        if (!nif.isUp || nif.isLoopback) continue
        for (addr in java.util.Collections.list(nif.inetAddresses)) {
            if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                addr.hostAddress?.let { found += it }
            }
        }
    }
    return found.toList()
}

internal fun isIgnoringBatteryOptimizations(context: Context): Boolean =
    context.getSystemService(PowerManager::class.java)
        ?.isIgnoringBatteryOptimizations(context.packageName) == true

internal fun isBackgroundUsageAllowed(context: Context): Boolean =
    context.getSystemService(ActivityManager::class.java)?.isBackgroundRestricted != true

private enum class BatteryAndroidGate { BACKGROUND, UNRESTRICTED }

/**
 * Fieldwatch’s per-app Battery page. Samsung keeps Allow background usage and
 * Unrestricted on this same screen. [highlightBackground] asks Settings to
 * focus the background-usage switch when the OEM supports it.
 */
private fun openAppBatteryPage(context: Context, highlightBackground: Boolean) {
    val pkgUri = Uri.fromParts("package", context.packageName, null)
    val attempts = listOf(
        Intent("android.settings.VIEW_ADVANCED_POWER_USAGE_DETAIL").apply {
            data = pkgUri
            addCategory(Intent.CATEGORY_DEFAULT)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("request_ignore_background_restriction", highlightBackground)
            if (!highlightBackground) {
                putExtra(":settings:fragment_args_key", "unrestricted_pref")
            }
        },
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = pkgUri
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        },
    )
    for (intent in attempts) {
        if (intent.resolveActivity(context.packageManager) == null) continue
        if (runCatching { context.startActivity(intent) }.isSuccess) return
    }
}

private fun openUrl(context: android.content.Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
