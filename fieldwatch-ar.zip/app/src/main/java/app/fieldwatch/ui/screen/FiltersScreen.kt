package app.fieldwatch.ui.screen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import app.fieldwatch.ui.component.FieldwatchActionButton
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalMinimumInteractiveComponentSize
import androidx.compose.material3.MaterialTheme
import app.fieldwatch.ui.component.FieldwatchOutlinedField
import androidx.compose.material3.Scaffold
import app.fieldwatch.ui.component.FieldwatchSlider
import androidx.compose.material3.Surface
import app.fieldwatch.ui.component.FieldwatchSwitch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.fieldwatch.domain.FilterLogic
import app.fieldwatch.domain.FilterPreset
import app.fieldwatch.domain.Fleet
import app.fieldwatch.domain.SignatureClass
import app.fieldwatch.ui.ClassGlyphs
import app.fieldwatch.ui.NestedTabInsets
import app.fieldwatch.ui.NestedTopBar
import app.fieldwatch.ui.FieldwatchUi
import app.fieldwatch.ui.FieldwatchViewModel
import app.fieldwatch.ui.component.SectionCard
import app.fieldwatch.ui.component.FieldwatchFilterChip
import app.fieldwatch.ui.component.spectreSectionFill
import app.fieldwatch.ui.component.spectreTileEdge
import app.fieldwatch.ui.component.spectreTileFill
import app.fieldwatch.ui.theme.LocalNightMode
import app.fieldwatch.ui.theme.PhosphorActive
import app.fieldwatch.ui.theme.nightIf

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FiltersScreen(state: FieldwatchUi, vm: FieldwatchViewModel) {
    var presetName by remember { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<FilterPreset?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    val filter = state.filter
    Scaffold(
        contentWindowInsets = NestedTabInsets,
        topBar = { NestedTopBar("المرشّحات") },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard("الإعدادات المسبقة") {
            Text(
                "اضغط إعداداً مسبقاً لاستبدال المرشّح كله. اضغط مطولاً لحذفه. " +
                    "«حفظ الحالي باسم…» يحتفظ بالمرشّح الذي لديك الآن. " +
                    "«الإعدادات ← استعادة البصمات والإعدادات المسبقة الافتراضية» تعيد الإعدادات المسبقة الأساسية المحذوفة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides Dp.Unspecified) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    state.presets.chunked(2).forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            row.forEach { preset ->
                                PresetChip(
                                    name = preset.name,
                                    selected = preset.filter == filter,
                                    onApply = { vm.applyPreset(preset) },
                                    onLongPress = { pendingDelete = preset },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                FieldwatchOutlinedField(
                    presetName,
                    { presetName = it },
                    "حفظ الحالي باسم…",
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = {
                    if (presetName.isNotBlank()) {
                        vm.savePreset(presetName.trim())
                        presetName = ""
                    }
                }) { Text("حفظ") }
            }
            }

            SectionCard("المصادر") {
            Text(
                if (filter.movingWithYou) {
                    "«التحرك معك» يستخدم BLE فقط. «الاثنان» و«Wi-Fi فقط» يبقيان غير متاحين حتى توقف ذلك المفتاح."
                } else {
                    "اختر المصادر التي يعرضها المباشر. المصدر الواحد هو Wi-Fi أو BLE، وليس الاثنين."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FieldwatchFilterChip(
                    selected = !filter.movingWithYou && filter.showWifi && filter.showBle,
                    onClick = { vm.updateFilter { it.copy(showWifi = true, showBle = true) } },
                    enabled = !filter.movingWithYou,
                    label = { Text("الاثنان") },
                )
                FieldwatchFilterChip(
                    selected = !filter.movingWithYou && filter.showWifi && !filter.showBle,
                    onClick = { vm.updateFilter { it.copy(showWifi = true, showBle = false) } },
                    enabled = !filter.movingWithYou,
                    label = { Text("Wi-Fi فقط") },
                )
                FieldwatchFilterChip(
                    selected = filter.movingWithYou || (filter.showBle && !filter.showWifi),
                    onClick = { vm.updateFilter { it.copy(showWifi = false, showBle = true) } },
                    label = { Text("BLE فقط") },
                )
            }
            }

            SectionCard("التحرك معك") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("التحرك معك", Modifier.weight(1f))
                FieldwatchSwitch(
                    filter.movingWithYou,
                    { on ->
                        vm.updateFilter { current ->
                            if (!on) current.copy(movingWithYou = false)
                            else {
                                // Follow test is BLE. Leftover Trackers / Show only hides
                                // unmatched rows; AirTags rotate, so Live looks empty.
                                val hiding = current.useClassFilter && current.excludeClasses
                                current.copy(
                                    movingWithYou = true,
                                    showWifi = false,
                                    showBle = true,
                                    namedOnly = false,
                                    customNamesOnly = false,
                                    watchedOnly = false,
                                    useClassFilter = hiding,
                                    excludeClasses = hiding,
                                    classes = if (hiding) current.classes else emptySet(),
                                    includeSignatures = false,
                                )
                            }
                        }
                    },
                )
            }
            Text(
                when {
                    !state.settings.tagLocation ->
                        "فعّل «وسم الرصد بـ GPS» ثم امشِ أو قُد. " +
                            "يُظهر هذا مصادر Bluetooth القوية التي تبقى معك. تبقى نقاط وصول Wi-Fi مخفية. " +
                            "تفعيله يمسح مرشّحات «فقط» الأخرى، باستثناء «إخفاء هذه»."
                    state.operatorSpanM < 45.0 ->
                        "مسار GPS حتى الآن ${state.operatorSpanM.toInt()} م. استمر في التحرك حتى نحو 50 م. " +
                            "إن بقي هذا عند 0 أثناء القيادة فاضبط الموقع على الدقة العالية. " +
                            "الهاتف الذي يغيّر عنوان Bluetooth باستمرار لن يطابق." +
                            when {
                                filter.customNamesOnly ->
                                    " «المصادر المسمّاة فقط» مفعّل أيضاً، لذا تبقى المصادر بلا تسمية مخفية."
                                filter.watchedOnly ->
                                    " «المراقَب فقط» مفعّل أيضاً، لذا تبقى المصادر غير المراقَبة مخفية."
                                filter.namedOnly || filter.namedOnlyImplied() ->
                                    " «البصمات فقط» أو «إظهار فقط» مفعّل أيضاً، لذا تبقى المصادر غير المطابقة مخفية."
                                else -> ""
                            } +
                            if (filter.hideMine) " «إخفاء مصادري» مفعّل، لذا تبقى تلك خارج هذه القائمة." else ""
                    filter.customNamesOnly || filter.watchedOnly || filter.namedOnly || filter.namedOnlyImplied() ->
                        "مسار GPS ${state.operatorSpanM.toInt()} م. مرشّح «فقط» آخر مفعّل، لذا لا يطابق إلا تلك المصادر. " +
                            "وسم في حقيبة أو سيارة يجب أن يظهر. يبقى Wi-Fi مخفياً." +
                            if (filter.hideMine) " «إخفاء مصادري» مفعّل، لذا تبقى تلك خارج هذه القائمة." else ""
                    else ->
                        "مسار GPS ${state.operatorSpanM.toInt()} م. Bluetooth قوي سُمع على طول ذلك المسار بمستوى ثابت. " +
                            (if (filter.hideMine) {
                                "«إخفاء مصادري» مفعّل، لذا تبقى تلك خارج هذه القائمة. "
                            } else {
                                "وسم في حقيبة أو سيارة يجب أن يظهر. "
                            }) +
                            "يبقى Wi-Fi مخفياً لأن نقطة وصول قوية قد تبدو كأنها تسافر معك. " +
                            "الهاتف الذي يغيّر عنوان Bluetooth باستمرار لن يظهر كتابع واحد. " +
                            "«المباشر ← البدء من جديد» يمسح المسار لتختبر مجدداً."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }

            SectionCard("الرصدات الجديدة") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (state.arrivalsLearning) "الرصدات الجديدة فقط  ·  تعلّم" else "الرصدات الجديدة فقط",
                    Modifier.weight(1f),
                )
                FieldwatchSwitch(
                    filter.arrivalsOnly,
                    { on -> vm.updateFilter { it.copy(arrivalsOnly = on) } },
                )
            }
            Text(
                if (filter.arrivalsOnly) {
                    "«تعليم كمُشاهَد» و«إعادة ضبط المُشاهَد» في المباشر، فوق التبويبات. " +
                        when {
                            state.arrivalsLearning ->
                                "جارٍ تعلّم شبكات Wi-Fi الموجودة بالفعل هنا."
                            state.hiddenKnown > 0 ->
                                "${state.hiddenKnown} مصدر مرئي سابقاً مخفي."
                            else ->
                                "لم يُعلَّم شيء كمُشاهَد بعد."
                        }
                } else {
                    "يخفي المصادر الموجودة بالفعل ليُظهر المباشر الجديدة فقط. " +
                        "يظهر «تعليم كمُشاهَد» و«إعادة ضبط المُشاهَد» في المباشر ما دام هذا مفعّلاً. " +
                        "«إبقاء قصير» يحدد المدة التي يبقى فيها مصدر جديد بعد آخر حزمة. " +
                        "مصدر Bluetooth يغيّر عنوانه يبدو جديداً."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }

            SectionCard("مَن يبقى") {
            val namedImplied = filter.namedOnlyImplied()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "البصمات فقط (إخفاء غير المطابق)",
                    Modifier.weight(1f),
                    color = if (namedImplied) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                )
                FieldwatchSwitch(
                    checked = filter.namedOnly || namedImplied,
                    onCheckedChange = { on ->
                        if (!namedImplied) vm.updateFilter { it.copy(namedOnly = on) }
                    },
                    enabled = !namedImplied,
                )
            }
            if (namedImplied) {
                Text(
                    "«إظهار فقط» يخفي بالفعل المصادر غير المطابقة. أوقف «إظهار فقط» لتستخدم هذا المفتاح.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("المراقَب فقط", Modifier.weight(1f))
                FieldwatchSwitch(
                    filter.watchedOnly,
                    { on -> vm.updateFilter { it.copy(watchedOnly = on) } },
                )
            }
            Text(
                "يعرض المباشر البصمات ذات الإشارة المرجعية، والمصادر المسمّاة مع تفعيل التنبيه. «إخفاء هذه» ما زال ساري المفعول. الاسم بلا إشارة مرجعية يبقى ضمن «المصادر المسمّاة فقط».",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("المصادر المسمّاة فقط", Modifier.weight(1f))
                FieldwatchSwitch(
                    filter.customNamesOnly,
                    { on -> vm.updateFilter { it.copy(customNamesOnly = on) } },
                )
            }
            Text(
                "يعرض المباشر المصادر التي سمّيتها. يمكن أن يكون التنبيه متوقفاً. المصدر الذي يغيّر عنوانه لن يحتفظ بذلك الاسم.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إخفاء مصادري", Modifier.weight(1f))
                FieldwatchSwitch(
                    filter.hideMine,
                    { on -> vm.updateFilter { it.copy(hideMine = on) } },
                )
            }
            Text(
                "المصادر الموسومة «لي» تبقى خارج المباشر. وتبقى في الجلسة وملخص الرصد. «التحرك معك» يترك هذا مفعّلاً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إخفاء مفتاح حساب Fast Pair", Modifier.weight(1f))
                FieldwatchSwitch(
                    filter.hideFastPairAccountKey,
                    { on -> vm.updateFilter { it.copy(hideFastPairAccountKey = on) } },
                )
            }
            Text(
                "يخفي مصادر Fast Pair المقترنة بالفعل التي لا تطابق أي بصمة أخرى. تبقى المصادر التي ما زالت في وضع الاقتران. «إخفاء البصمات المحددة» قد يخفيها أيضاً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }

            SectionCard("فئات البصمات") {
            Text(
                "للمباشر فقط. تبقى البصمات تُسمّي وتسجّل ويمكن أن تصفّر. اختر «إظهار فقط» أو «إخفاء هذه» ثم الفئات. «إظهار فقط» دون اختيار شيء يترك المباشر كما هو. «حفظ الحالي باسم…» يحفظ هذا إعداداً مسبقاً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FieldwatchFilterChip(
                    selected = filter.useClassFilter && !filter.excludeClasses,
                    onClick = {
                        vm.updateFilter {
                            val on = !(it.useClassFilter && !it.excludeClasses)
                            it.copy(useClassFilter = on, excludeClasses = false)
                        }
                    },
                    label = { Text("إظهار فقط") },
                )
                FieldwatchFilterChip(
                    selected = filter.useClassFilter && filter.excludeClasses,
                    onClick = {
                        vm.updateFilter {
                            val on = !(it.useClassFilter && it.excludeClasses)
                            it.copy(useClassFilter = on, excludeClasses = on)
                        }
                    },
                    label = { Text("إخفاء هذه") },
                )
            }
            CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides Dp.Unspecified) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SignatureClass.visible.sortedBy { it.label().lowercase() }.chunked(2).forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            row.forEach { kind ->
                                val on = kind in filter.classes
                                FieldwatchFilterChip(
                                    selected = on,
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(max = 32.dp),
                                    onClick = {
                                        vm.updateFilter { current ->
                                            val next = current.classes.toMutableSet()
                                            if (on) next.remove(kind) else next.add(kind)
                                            current.copy(classes = next)
                                        }
                                    },
                                    leadingIcon = {
                                        Icon(
                                            ClassGlyphs.of(kind),
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                        )
                                    },
                                    label = {
                                        Text(
                                            kind.label(),
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    },
                                )
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            }

            SectionCard("البصمات المحددة") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إظهار البصمات المحددة فقط", Modifier.weight(1f))
                FieldwatchSwitch(
                    filter.includeSignatures,
                    { on -> vm.updateFilter { it.copy(includeSignatures = on) } },
                )
            }
            if (filter.includeSignatures) {
                SignaturePickList(
                    fleets = state.fleets,
                    selected = filter.includeFleetIds,
                    help = "اضغط فئة لفتحها. يحتفظ المباشر بالمصادر المطابقة لبصمة فعّلتها. القائمة الفارغة تترك المباشر كما هو. تبقى اختياراتك إن أوقفت هذا ثم شغّلته.",
                    onToggle = { id, checked ->
                        vm.updateFilter { current ->
                            val next = current.includeFleetIds.toMutableSet()
                            if (checked) next.add(id) else next.remove(id)
                            current.copy(includeFleetIds = next)
                        }
                    },
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إخفاء البصمات المحددة", Modifier.weight(1f))
                FieldwatchSwitch(
                    filter.excludeSignatures,
                    { on -> vm.updateFilter { it.copy(excludeSignatures = on) } },
                )
            }
            if (filter.excludeSignatures) {
                SignaturePickList(
                    fleets = state.fleets,
                    selected = filter.fleetIds,
                    help = "اضغط فئة لفتحها. المصادر المطابقة لبصمة فعّلتها تبقى خارج المباشر. تبقى اختياراتك إن أوقفت هذا ثم شغّلته.",
                    onToggle = { id, checked ->
                        vm.updateFilter { current ->
                            val next = current.fleetIds.toMutableSet()
                            if (checked) next.add(id) else next.remove(id)
                            current.copy(fleetIds = next)
                        }
                    },
                )
            }
            }

            SectionCard("المرشّح الدقيق") {
            var rssiDrag by remember { mutableIntStateOf(filter.rssiMin) }
            var rssiDragging by remember { mutableStateOf(false) }
            LaunchedEffect(filter.rssiMin) {
                if (!rssiDragging) rssiDrag = filter.rssiMin
            }
            Text("أدنى RSSI  $rssiDrag dBm", style = MaterialTheme.typography.labelLarge)
            FieldwatchSlider(
                value = rssiDrag.toFloat(),
                onValueChange = { v ->
                    rssiDragging = true
                    rssiDrag = v.toInt()
                },
                onValueChangeFinished = {
                    vm.updateFilter { it.copy(rssiMin = rssiDrag) }
                    rssiDragging = false
                },
                valueRange = -100f..-30f,
            )

            FieldwatchOutlinedField(
                filter.nameQuery,
                { value -> vm.updateFilter { it.copy(nameQuery = value) } },
                "الاسم / MAC يحتوي",
            )
            FieldwatchOutlinedField(
                filter.ouiQuery,
                { value -> vm.updateFilter { it.copy(ouiQuery = value) } },
                "الشركة المصنّعة تحتوي",
            )

            Text("الاسم والشركة والإشارة والفئة", style = MaterialTheme.typography.labelLarge)
            Text(
                "AND تعني أن كل هذه تتطابق. OR تعني أي واحد منها. لا يغيّر هذا نوع المصدر، ولا مفاتيح «فقط»، ولا «إخفاء مصادري»، ولا «إخفاء Fast Pair»، ولا قائمة إخفاء.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FieldwatchFilterChip(
                    selected = filter.logic == FilterLogic.AND,
                    onClick = { vm.updateFilter { it.copy(logic = FilterLogic.AND) } },
                    label = { Text("AND") },
                )
                FieldwatchFilterChip(
                    selected = filter.logic == FilterLogic.OR,
                    onClick = { vm.updateFilter { it.copy(logic = FilterLogic.OR) } },
                    label = { Text("OR") },
                )
            }

            FieldwatchActionButton(onClick = { confirmReset = true }) {
                Text("إعادة ضبط المرشّح")
            }
            }
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("إعادة ضبط المرشّح؟") },
            text = {
                Text(
                    "يمسح المصادر والفئات والبصمات المحددة وقوة الإشارة وحقلي الاسم والشركة. " +
                        "تبقى الإعدادات المسبقة التي حفظتها. يعرض المباشر المصادر مجدداً. لا يمكن التراجع عن هذا.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmReset = false
                        vm.updateFilter { app.fieldwatch.domain.FilterState() }
                    },
                ) { Text("إعادة ضبط") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("إلغاء") }
            },
        )
    }
    pendingDelete?.let { preset ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("حذف الإعداد المسبق؟") },
            text = {
                Text(
                    if (preset.isBuiltIn()) {
                        "إزالة “${preset.name}” من هذه القائمة؟ تحديث الكتالوج لن يعيده. «الإعدادات ← استعادة البصمات والإعدادات المسبقة الافتراضية» تعيد الإعدادات المسبقة الأساسية. يحتفظ المباشر بهذا المرشّح حتى تختار إعداداً مسبقاً آخر أو تضغط «إعادة ضبط المرشّح»."
                    } else {
                        "حذف “${preset.name}”؟ لا يمكن التراجع عن هذا. يحتفظ المباشر بهذا المرشّح حتى تختار إعداداً مسبقاً آخر أو تضغط «إعادة ضبط المرشّح»."
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePreset(preset.id)
                    pendingDelete = null
                }) { Text("حذف") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("إلغاء") }
            },
        )
    }
}

@Composable
private fun SignaturePickList(
    fleets: List<Fleet>,
    selected: Set<String>,
    help: String,
    onToggle: (id: String, checked: Boolean) -> Unit,
) {
    val groups = remember(fleets) {
        fleets.groupBy { it.kind.folded() }
            .toList()
            .sortedBy { it.first.label().lowercase() }
            .map { (kind, rows) -> kind to rows.sortedBy { it.name.lowercase() } }
    }
    var open by remember {
        mutableStateOf(
            groups.filter { (_, rows) -> rows.any { it.id in selected } }
                .map { it.first.name }
                .toSet(),
        )
    }
    Column(
        modifier = Modifier.padding(start = 24.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            help,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        groups.forEach { (kind, rows) ->
            val classId = kind.name
            val expanded = classId in open
            val picked = rows.count { it.id in selected }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        open = if (expanded) open - classId else open + classId
                    }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    ClassGlyphs.of(kind),
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    kind.label(),
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    buildString {
                        append(if (expanded) "▾  " else "▸  ")
                        if (picked > 0) append("$picked/")
                        append(rows.size)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (picked > 0) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
            if (expanded) {
                rows.forEach { fleet ->
                    val on = fleet.id in selected
                    Row(
                        modifier = Modifier.padding(start = 24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(fleet.name, Modifier.weight(1f))
                        FieldwatchSwitch(on, { checked -> onToggle(fleet.id, checked) })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PresetChip(
    name: String,
    selected: Boolean = false,
    onApply: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = FilterChipDefaults.shape,
        color = if (selected) spectreSectionFill() else spectreTileFill(),
        border = BorderStroke(
            1.dp,
            if (selected) PhosphorActive.nightIf(LocalNightMode.current) else spectreTileEdge(),
        ),
        modifier = modifier
            .heightIn(max = 32.dp)
            .combinedClickable(
                onClick = onApply,
                onLongClick = onLongPress,
            ),
    ) {
        Text(
            name,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
