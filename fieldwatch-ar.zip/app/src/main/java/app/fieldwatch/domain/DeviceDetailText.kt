package app.fieldwatch.domain

import app.fieldwatch.radio.BleAdParser
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Plain-text dump of the device-detail screen. Same fields, no sparkline/presence art.
 * Not a legal identity.
 */
object DeviceDetailText {
    fun build(
        device: Sighting,
        signatureNames: List<String>,
        now: Long = System.currentTimeMillis(),
        attentionNotes: List<Pair<String, String>> = emptyList(),
        signatureNotes: List<Pair<String, String>> = emptyList(),
        fleets: List<Fleet> = emptyList(),
        mine: Boolean = false,
    ): String {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        val iso = SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US)
        val facts = device.facts
        val title = device.listTitle(signatureNames)
        val guess = DeviceExplain.guess(device, signatureNames)
        val out = StringBuilder()

        fun line(label: String, value: String) {
            out.append(label).append(": ").append(value.trim()).append('\n')
        }
        fun section(title: String) {
            out.append('\n').append("## ").append(title).append('\n')
        }

        out.append("تفاصيل جهاز Fieldwatch\n")
        out.append(iso.format(Date(now))).append('\n')
        out.append(
            "تجريبي. ليست هوية قانونية. مصادر أندرويد الأصلية — هذا ما كشفه النظام، " +
                "وليس ضماناً بوجود جهاز تتبع أو كاميرا.\n",
        )
        out.append('\n')
        out.append(title).append('\n')
        line("MAC", device.mac)
        if (device.name.isNotBlank()) line("الاسم المُعلَن", device.name)
        if (mine) line("موسوم «لي»", "لا صفير ما دام هذا مفعّلاً. ويبقى في القائمة.")

        out.append('\n')
        out.append("ما الذي يشبهه هذا: ").append(guess.headline).append('\n')
        out.append(guess.because).append('\n')
        if (attentionNotes.isNotEmpty()) {
            section("انتباه إضافي")
            attentionNotes.forEach { (name, note) ->
                out.append("انتباه إضافي ($name): ").append(note.trim()).append('\n')
            }
            out.append("مطابقة نمط، وليست هوية. وليست استنتاجاً أمنياً.\n")
        }
        if (signatureNotes.isNotEmpty()) {
            section("ملاحظات")
            signatureNotes.forEach { (name, note) ->
                out.append(name).append(": ").append(note.trim()).append('\n')
            }
        }

        section("الهوية")
        line(
            "المصدر",
            if (device.kind == RadioKind.WIFI) {
                "نقطة وصول Wi-Fi (تبثّ شبكة)"
            } else {
                "معلِن Bluetooth منخفض الطاقة"
            },
        )
        line("العنوان", DeviceExplain.addressExplain(device))
        vendorLine(device)?.let { line("مَن صنعه", it.replace('\n', ' ')) }
            ?: line("OUI (بادئة الشركة المصنّعة)", "${device.oui} — لا يوجد تطابق في IEEE؛ العناوين العشوائية لا يكون لها غالباً")
        if (device.hiddenSsid) {
            line("اسم الشبكة (SSID)", "مخفي — نقطة الوصول تبثّ لكنها لا تنشر اسماً")
        }

        section("الإشارة")
        if (device.gone) {
            line("قوتها هنا (RSSI)", "غير متاح")
            val last = Rssi.lastMeasured(device.rssi, device.rssiHistory)
            line("آخر سماع", last?.let { "$it dBm" } ?: "غير متاح")
        } else {
            line("قوتها هنا (RSSI)", DeviceExplain.rssiExplain(device.rssi))
            out.append("كلما اقترب من 0 dBm كانت أقوى هنا، وهذا ليس مسافة.\n")
        }
        line("المدى المسموع في هذه الجلسة", Rssi.sessionRange(device.rssiMin, device.rssiMax, device.rssiHistory))
        facts.txPowerDbm?.let {
            line("قدرة الإرسال المُدّعاة", "$it dBm — قوة إرساله كما يدّعي، وليست مسافة")
        }
        if (device.channel != 0 || device.frequencyMhz != 0) {
            line(
                "القناة / التردد",
                buildString {
                    if (device.channel != 0) append("القناة ${device.channel}")
                    if (device.frequencyMhz != 0) {
                        if (isNotEmpty()) append("  ·  ")
                        append("${device.frequencyMhz} MHz")
                    }
                    facts.channelWidth?.let { append("  ·  العرض $it") }
                },
            )
        }
        facts.wifiStandard?.let { line("جيل Wi-Fi", it) }
        if (facts.centerFreq0 != null || facts.centerFreq1 != null) {
            line(
                "الترددات المركزية",
                listOfNotNull(
                    facts.centerFreq0?.let { "$it MHz" },
                    facts.centerFreq1?.let { "$it MHz" },
                ).joinToString("  ·  "),
            )
        }
        val rssiTail = device.rssiHistory.filter { Rssi.measured(it.rssi) }.takeLast(24)
        if (rssiTail.isNotEmpty()) {
            line(
                "RSSI الأخير (من الأقدم إلى الأحدث)",
                rssiTail.joinToString(", ") { it.rssi.toString() },
            )
        }

        if (device.kind == RadioKind.BLE) {
            section("إعلان Bluetooth")
            facts.primaryPhy?.let {
                val phys = listOfNotNull(it, facts.secondaryPhy).distinct()
                line("طبقة الراديو PHY", phys.joinToString(" / ") { phy -> DeviceExplain.phyExplain(phy) })
            }
            facts.connectable?.let {
                line(
                    "قابل للاتصال",
                    if (it) "نعم — يمكن لهاتف فتح اتصال BLE"
                    else "لا — بثّ فقط (يمكنك سماعه لكن لا الانضمام إليه من هذا المسح)",
                )
            }
            facts.advertisingIntervalMs?.let {
                line("كم مرة يُعلن", "%.0f ms بين الدفعات (الأصغر = أكثر ثرثرة على الهواء)".format(it))
            }
            facts.periodicIntervalMs?.let { line("الإعلان الدوري", "%.0f ms".format(it)) }
            facts.advFlags?.let { flags ->
                line("قابلية الاكتشاف", DeviceExplain.flagsExplain(flags))
                line("الأعلام (خام)", "0x%02X".format(flags))
            }
            facts.appearance?.let { value ->
                val name = RadioDb.appearance(value)
                line(
                    "ما يقول إنه هو (Appearance)",
                    name ?: "Appearance غير مدرج 0x%04X".format(value),
                )
                line("رمز Appearance", "0x%04X".format(value))
            }
            CodDecoder.decodeOrNull(facts.deviceClass)?.let { cod ->
                line(
                    "فئة Bluetooth الكلاسيكي",
                    buildString {
                        append(cod.major)
                        if (cod.minor.isNotBlank()) append(" / ").append(cod.minor)
                        if (cod.services.isNotEmpty()) {
                            append(". ويقدّم أيضاً: ")
                            append(cod.services.joinToString(", "))
                        }
                    },
                )
            }
        }

        if (device.kind == RadioKind.WIFI) {
            section("نقطة وصول Wi-Fi")
            facts.security?.let {
                line("التشفير / تسجيل الدخول", DeviceExplain.wifiSecurityExplain(it))
                if (it.isNotBlank()) line("سلسلة الأمان", it)
            }
            facts.supportedRates?.let { line("المعدلات المدعومة", "$it Mbps  (* = معدل أساسي مطلوب)") }
            facts.capabilities?.takeIf { it.isNotBlank() && it != facts.security }?.let {
                line("سلسلة القدرات", it)
            }
        }

        device.payloadAircraft?.trim()?.takeIf { it.isNotEmpty() }?.let { line("طائرة", it) }

        if (fleets.isNotEmpty() && (device.kind == RadioKind.BLE || device.kind == RadioKind.WIFI)) {
            val decoded = SignatureFieldDecoder.decodeSighting(device, fleets)
            if (decoded.isNotEmpty()) {
                section("الحقول المفكوكة")
                decoded.forEach { row ->
                    line(row.label, row.display)
                    if (row.note.isNotBlank()) line("ملاحظة", row.note)
                }
            }
        }

        if (device.serviceUuids.isNotEmpty()) {
            section("الخدمات التي يقدّمها")
            line(
                "معرّفات الخدمات",
                device.serviceUuids.joinToString("; ") { uuid ->
                    DeviceExplain.uuidGloss(uuid)?.let { "$uuid  ·  $it" } ?: uuid
                },
            )
        }
        if (facts.serviceData.isNotEmpty()) {
            facts.serviceData.forEach { sd ->
                val named = RadioDb.serviceUuid(sd.uuid)?.let { " ($it)" } ?: ""
                AdvPayloadDecoder.decodeService(sd).forEach { field -> line(field.label, field.value) }
                line(
                    "بيانات الخدمة ${uuidShort(sd.uuid)}$named",
                    sd.dataHex.hexSpaced().ifBlank { "(فارغ)" },
                )
            }
        }

        val mfg = facts.mfgRecords.ifEmpty {
            device.manufacturerId?.let {
                listOf(MfgRecord(it, device.manufacturerDataHex))
            } ?: emptyList()
        }
        if (mfg.isNotEmpty()) {
            section("بيانات المصنّع داخل الإعلان")
            mfg.forEach { rec ->
                val company = RadioDb.company(rec.companyId) ?: "غير موجودة في قائمة شركات Bluetooth"
                line("شركة Bluetooth 0x%04X".format(rec.companyId), company)
                BleAdParser.mfgDecodedFields(rec).forEach { (k, v) -> line(k, v) }
                if (rec.dataHex.isNotBlank()) {
                    line("الحمولة الخام (${rec.dataHex.length / 2} بايت)", rec.dataHex.hexSpaced())
                }
            }
        }

        if (facts.vendorIes.isNotEmpty() || device.vendorIeOuis.isNotEmpty()) {
            section("وسوم مورّد Wi-Fi")
            val rows = facts.vendorIes.ifEmpty {
                device.vendorIeOuis.map { VendorIeRecord(it, -1, "") }
            }
            rows.forEach { ie ->
                val org = RadioDb.vendorForOui24(ie.oui)
                val type = if (ie.type >= 0) " النوع %d".format(ie.type) else ""
                line(
                    "OUI المورّد ${ie.oui}$type",
                    buildString {
                        append(org ?: "OUI غير معروف في IEEE")
                        append(" — عنصر معلومات إضافي لنقطة الوصول، وليس SSID.")
                        if (ie.dataHex.isNotBlank()) {
                            append(" ")
                            append(ie.dataHex.hexSpaced())
                        }
                    },
                )
            }
        }

        section("الجلسة")
        line("أول ظهور", fmt.format(Date(device.firstSeen)))
        line("آخر ظهور", fmt.format(Date(device.lastSeen)))
        line("الرصدات", device.hitCount.toString())
        Geo.screenCoord(device.latitude, device.longitude, false)?.let {
            line("آخر تحديد موقع", it)
            out.append("آخر موقع هو موقع GPS للهاتف وقت السماع، وليس تحديداً لموقع هذا المصدر.\n")
        }
        if (device.fleetIds.isNotEmpty()) {
            line("البصمات المطابقة", signatureNames.joinToString("; ").ifBlank {
                device.fleetIds.joinToString("; ")
            })
        }
        if (device.rawHex.isNotBlank() && device.kind == RadioKind.BLE) {
            line("الإعلان الخام", device.rawHex.hexSpaced())
        }
        presenceLine(device, now, fmt)?.let { line("الحضور (15 دقيقة)", it) }
        return out.toString().trimEnd() + "\n"
    }

    private fun vendorLine(device: Sighting): String? {
        val parts = ArrayList<String>(3)
        device.vendor?.let {
            parts += "مورّد اللوحة/الشريحة في IEEE: $it (${device.oui}). هذا مالك بادئة MAC، وليس دائماً علامة المنتج التجارية."
        }
        val mfgId = device.facts.mfgRecords.firstOrNull()?.companyId ?: device.manufacturerId
        if (mfgId != null) {
            val company = RadioDb.company(mfgId)
            parts += "Bluetooth company in the ad: ${company ?: "unlisted"} (0x%04X).".format(mfgId)
        }
        return parts.joinToString(" ").ifBlank { null }
    }

    private fun uuidShort(uuid: String): String {
        val hex = uuid.filter { it.isLetterOrDigit() }.uppercase()
        return if (hex.length >= 8 && hex.startsWith("0000")) hex.substring(4, 8) else uuid.take(8)
    }

    private fun presenceLine(device: Sighting, now: Long, fmt: SimpleDateFormat): String? {
        if (device.presence.isEmpty()) return null
        val from = now - 15 * 60 * 1000L
        val spans = device.presence.filter { (it.end ?: now) >= from }
        if (spans.isEmpty()) return null
        return spans.joinToString("; ") { span ->
            val start = fmt.format(Date(span.start.coerceAtLeast(from)))
            val end = span.end?.let { fmt.format(Date(it)) } ?: "الآن"
            "$start–$end"
        }
    }
}
