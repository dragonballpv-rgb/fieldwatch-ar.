package app.fieldwatch.domain

/**
 * Settings → Diagnostics. Phone and scan facts only.
 * No network names, MACs, or GPS coordinates.
 */
enum class HeaderTone { OFF, IDLE, HEALTHY, PROBLEM }

/** Wi-Fi icon in the list header. Green is healthy, including the wait between scans. */
fun wifiHeader(scanning: Boolean, locationOn: Boolean, radio: ScanRadioFacts): Pair<HeaderTone, String> {
    if (!radio.wifiOn) return HeaderTone.OFF to "Wi-Fi متوقف"
    if (!scanning) return HeaderTone.IDLE to "Wi-Fi خامل"
    if (!locationOn) return HeaderTone.PROBLEM to "Wi-Fi، الموقع متوقف"
    if (radio.wifiWaitingOnOs) return HeaderTone.PROBLEM to "Wi-Fi ينتظر أندرويد"
    return HeaderTone.HEALTHY to "Wi-Fi يعمل"
}

/**
 * GPS icon in the list header. Null when the check is off.
 * Green is armed and quiet. A hit is red. A pause, a Poor phone, and the warmup stay muted.
 */
fun gpsHeader(
    monitorOn: Boolean,
    suppressAlerts: Boolean,
    scanning: Boolean,
    statusLine: String,
    alertShowing: Boolean,
): Pair<HeaderTone, String>? {
    if (!monitorOn) return null
    if (alertShowing) return HeaderTone.PROBLEM to "تنبيه GPS"
    if (statusLine == GnssCopy.PAUSED) return HeaderTone.IDLE to "GPS متوقف مؤقتاً"
    if (!scanning || suppressAlerts) return HeaderTone.IDLE to "GPS يعمل"
    val ready = statusLine == "armed" || statusLine.startsWith("AGC not available")
    return if (ready) HeaderTone.HEALTHY to "GPS يعمل" else HeaderTone.IDLE to "GPS يعمل"
}

/** Bluetooth icon in the list header. A planned rest stays healthy. */
fun bleHeader(scanning: Boolean, locationOn: Boolean, radio: ScanRadioFacts): Pair<HeaderTone, String> {
    if (!radio.bleOn) return HeaderTone.OFF to "Bluetooth متوقف"
    if (!scanning) return HeaderTone.IDLE to "Bluetooth خامل"
    if (!locationOn) return HeaderTone.PROBLEM to "Bluetooth، الموقع متوقف"
    val stuck = !radio.bleRunning && !radio.bleParked && !radio.bleRetrying && !radio.bleStarting
    if (radio.bleRetrying || stuck) return HeaderTone.PROBLEM to "Bluetooth ينتظر أندرويد"
    return HeaderTone.HEALTHY to "Bluetooth يعمل"
}

data class ScanRadioFacts(
    val scanning: Boolean = false,
    val wifiOn: Boolean = false,
    val wifiWaitingOnOs: Boolean = false,
    val lastWifiScanAt: Long = 0L,
    val bleOn: Boolean = false,
    val bleRunning: Boolean = false,
    val bleParked: Boolean = false,
    val bleRetrying: Boolean = false,
    val bleStarting: Boolean = false,
    val bleHitsLastMin: Int = 0,
)

data class ScanPhoneFacts(
    val versionName: String,
    val versionCode: Int,
    val catalogVersion: Int,
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val fingerprint: String,
    val locationOn: Boolean,
    val locationPermission: Boolean,
    /** Milliseconds since the last GPS fix. Null when this phone has none. */
    val gpsFixAgeMs: Long?,
    val arrivalsOnly: Boolean = false,
    val watchedOnly: Boolean = false,
    val customNamesOnly: Boolean = false,
    val showOnly: Boolean = false,
    val movingWithYou: Boolean = false,
    val showWifi: Boolean = true,
    val showBle: Boolean = true,
    val nameFilter: Boolean = false,
    val ouiFilter: Boolean = false,
    /** Settings switch. Fast scans run only when this is on and the OS is not throttling. */
    val wifiFastScan: Boolean = false,
    val wifiOsThrottled: Boolean = false,
    val backgroundUsage: Boolean = false,
    val unrestrictedBattery: Boolean = false,
)

data class ScanStatusReport(
    val rows: List<Pair<String, String>>,
    val verdict: String,
    /** Plain steps for the person holding the phone. Empty never happens. */
    val checks: List<String>,
    val text: String,
    val blocked: Boolean,
)

object ScanStatus {
    fun report(
        radio: ScanRadioFacts,
        phone: ScanPhoneFacts,
        now: Long,
        radiosOnAir: Int = 0,
        gnssRows: List<Pair<String, String>> = emptyList(),
    ): ScanStatusReport {
        val rows = listOf(
            "App" to "${phone.versionName} (${phone.versionCode})",
            "Catalog" to phone.catalogVersion.toString(),
            "Phone" to "${phone.manufacturer} ${phone.model}".trim(),
            "Android" to "${phone.androidRelease} (API ${phone.sdkInt})",
            "Fingerprint" to phone.fingerprint,
            "Wi-Fi" to if (radio.wifiOn) "on" else "off",
            "Last Wi-Fi scan" to lastWifi(radio, now),
            "Bluetooth" to if (radio.bleOn) "on" else "off",
            "BLE" to bleState(radio),
            "BLE results last minute" to radio.bleHitsLastMin.coerceAtLeast(0).toString(),
            "Faster Wi-Fi AP scans" to fasterWifi(phone),
            "Allow background usage" to onOff(phone.backgroundUsage),
            "Unrestricted battery" to onOff(phone.unrestrictedBattery),
            "Location" to if (phone.locationOn) "on" else "off",
            "Location permission" to if (phone.locationPermission) "granted" else "missing",
            "GPS fix" to ageLabel(phone.gpsFixAgeMs),
            "Filters" to filtersLabel(phone),
        ) + gnssRows
        val verdict = verdict(radio, phone, radiosOnAir)
        val checks = checks(radio, phone, radiosOnAir)
        val blocked = isBlocked(radio, phone.locationOn, phone.locationPermission)
        val text = buildString {
            rows.forEach { (k, v) -> append(k).append(": ").append(v).append('\n') }
            append("Verdict: ").append(verdict).append('\n')
            append("Check:\n")
            checks.forEach { append("- ").append(it).append('\n') }
        }
        return ScanStatusReport(rows, verdict, checks, text, blocked)
    }

    fun isBlocked(radio: ScanRadioFacts, locationOn: Boolean, locationPermission: Boolean): Boolean {
        if (!radio.scanning) return true
        if (!locationOn || !locationPermission) return true
        if (radio.bleStarting && !radio.bleRunning) return false
        return !wifiUsable(radio) && !bleUsable(radio)
    }

    /** Appended to an empty Live list while a scan is blocked. */
    const val EMPTY_POINTER = "Settings → Diagnostics."

    private fun wifiUsable(radio: ScanRadioFacts): Boolean =
        radio.wifiOn && !radio.wifiWaitingOnOs

    private fun bleUsable(radio: ScanRadioFacts): Boolean =
        radio.bleOn && radio.bleRunning && !radio.bleParked && !radio.bleRetrying

    private fun verdict(radio: ScanRadioFacts, phone: ScanPhoneFacts, radiosOnAir: Int): String {
        val wifiOk = wifiUsable(radio)
        val bleOk = bleUsable(radio)
        return when {
            !radio.scanning -> "المسح لا يعمل."
            !phone.locationOn -> "الموقع متوقف. لن يسلّم أندرويد نتائج المسح."
            !phone.locationPermission -> "إذن الموقع متوقف."
            !radio.wifiOn && !radio.bleOn -> "Wi-Fi وBluetooth متوقفان."
            radio.bleStarting && !radio.bleRunning && !radio.wifiWaitingOnOs -> "المسح قيد البدء."
            !wifiOk && !bleOk && radio.wifiWaitingOnOs && radio.bleParked ->
                "رُفض مسح Wi-Fi. مسح BLE متوقف مؤقتاً. المصدران يعملان."
            !wifiOk && !bleOk && radio.bleParked ->
                "مسح BLE متوقف مؤقتاً. Bluetooth يعمل."
            !wifiOk && !bleOk && radio.bleRetrying -> "مسح BLE يُعاد المحاولة."
            !wifiOk && !bleOk && radio.wifiWaitingOnOs ->
                "رُفض مسح Wi-Fi. Wi-Fi يعمل."
            !wifiOk && !bleOk -> "مسحا Wi-Fi وBluetooth لا يعملان."
            radio.wifiWaitingOnOs && bleOk -> "رُفض مسح Wi-Fi. BLE يعمل."
            radio.bleParked && wifiOk -> "مسح BLE متوقف مؤقتاً. Wi-Fi يعمل."
            !radio.wifiOn && bleOk -> "Wi-Fi متوقف. BLE يعمل."
            !radio.bleOn && wifiOk -> "Bluetooth متوقف. Wi-Fi يعمل."
            filterHiding(phone) -> "المسوح تعمل. مرشّح يخفي القائمة."
            radiosOnAir > 0 -> "المسوح تعمل."
            else -> "المسوح تعمل. لا شيء على الهواء."
        }
    }

    /**
     * What to turn on, in the order a person can fix it.
     * A radio that is off is named only when the other radio is still hearing.
     * Background usage, unrestricted battery, and a GPS fix are not required
     * while Fieldwatch is open, so they stay in the fact rows.
     */
    private fun checks(radio: ScanRadioFacts, phone: ScanPhoneFacts, radiosOnAir: Int): List<String> {
        val lines = mutableListOf<String>()
        if (!radio.scanning) {
            lines += "المسح لا يعمل. افتح «مباشر». إن طلب Fieldwatch إذناً فاسمح بالموقع والأجهزة القريبة والإشعارات."
        }
        if (!phone.locationOn) {
            lines += "فعّل الموقع. لن يُرجع أندرويد نتائج Wi-Fi أو Bluetooth ما دام الموقع متوقفاً."
        }
        if (!phone.locationPermission) {
            lines += "اسمح بالموقع لـ Fieldwatch. إعدادات الهاتف ← التطبيقات ← Fieldwatch ← الأذونات ← الموقع."
        }
        val wifiOk = wifiUsable(radio)
        val bleOk = bleUsable(radio)
        val locationReady = phone.locationOn && phone.locationPermission
        if (!radio.wifiOn && !radio.bleOn) {
            lines += "فعّل Wi-Fi أو Bluetooth. يسمع Fieldwatch نقاط الوصول وإعلانات Bluetooth."
        } else {
            if (!radio.wifiOn && bleOk) {
                lines += "Wi-Fi متوقف، لذا لن تظهر نقاط الوصول. Bluetooth يعمل."
            }
            if (!radio.bleOn && wifiOk) {
                lines += "Bluetooth متوقف، لذا لن تظهر مصادر Bluetooth. Wi-Fi يعمل."
            }
            if (locationReady && radio.wifiOn && radio.wifiWaitingOnOs) {
                lines += "مسوح Wi-Fi مرفوضة. راديو Wi-Fi يعمل. أوقف Wi-Fi ثم شغّله، ثم أعد فتح Fieldwatch."
            }
            if (locationReady && radio.bleOn && radio.bleParked) {
                lines += "مسوح Bluetooth متوقفة مؤقتاً. راديو Bluetooth يعمل. سيحاول Fieldwatch مجدداً."
            }
            if (radio.bleOn && radio.bleRetrying) {
                lines += "مسح Bluetooth يُعاد المحاولة. أوقف Bluetooth ثم شغّله، ثم أعد فتح Fieldwatch."
            }
            if (radio.bleOn && radio.bleStarting && !radio.bleRunning) {
                lines += "Bluetooth ما زال قيد البدء. انتظر بضع ثوانٍ."
            }
            if (radio.bleOn && !radio.bleRunning && !radio.bleParked && !radio.bleRetrying && !radio.bleStarting) {
                lines += "Bluetooth يعمل لكن المسح لا يعمل. أوقف Bluetooth ثم شغّله، ثم أعد فتح Fieldwatch."
            }
        }
        if (filterHiding(phone)) {
            lines += "مرشّح يخفي المصادر. المرشّحات هي ${filtersLabel(phone)}. اضبط المرشّحات على «كل الحركة» لترى كل ما يسمعه الهاتف."
        }
        if (lines.isEmpty()) {
            lines += if (radiosOnAir > 0) {
                "لا شيء مما يجب تشغيله متوقف. المسوح تعمل."
            } else {
                "لا شيء مما يجب تشغيله متوقف. المسوح تعمل. لا شيء على الهواء الآن."
            }
        }
        return lines
    }

    private fun filterHiding(phone: ScanPhoneFacts): Boolean =
        phone.arrivalsOnly || phone.watchedOnly || phone.customNamesOnly || phone.showOnly ||
            phone.movingWithYou || !phone.showWifi || !phone.showBle || phone.nameFilter || phone.ouiFilter

    private fun filtersLabel(phone: ScanPhoneFacts): String {
        val parts = buildList {
            if (phone.arrivalsOnly) add("الوصولات فقط")
            if (phone.watchedOnly) add("المراقَب فقط")
            if (phone.customNamesOnly) add("المصادر المسمّاة فقط")
            if (phone.showOnly) add("إظهار فقط")
            if (phone.movingWithYou) add("التحرك معك")
            if (!phone.showWifi) add("Wi-Fi مخفي")
            if (!phone.showBle) add("BLE مخفي")
            if (phone.nameFilter) add("مرشّح الاسم مفعّل")
            if (phone.ouiFilter) add("مرشّح OUI مفعّل")
        }
        return if (parts.isEmpty()) "كل الحركة" else parts.joinToString(", ")
    }

    private fun onOff(on: Boolean): String = if (on) "on" else "off"

    private fun fasterWifi(phone: ScanPhoneFacts): String =
        if (phone.wifiOsThrottled) "off" else "on"

    private fun lastWifi(radio: ScanRadioFacts, now: Long): String {
        val age = ageLabel(if (radio.lastWifiScanAt > 0L) now - radio.lastWifiScanAt else null)
        return when {
            radio.wifiWaitingOnOs && radio.lastWifiScanAt > 0L -> "waiting on OS ($age)"
            radio.wifiWaitingOnOs -> "waiting on OS"
            else -> age
        }
    }

    private fun bleState(radio: ScanRadioFacts): String = when {
        !radio.bleOn -> "off"
        radio.bleParked -> "parked"
        radio.bleRetrying -> "retrying"
        radio.bleStarting && !radio.bleRunning -> "starting"
        radio.bleRunning -> "running"
        else -> "not running"
    }

    private fun ageLabel(ageMs: Long?): String {
        if (ageMs == null || ageMs < 0L) return "none"
        val sec = (ageMs / 1000L).toInt()
        return if (sec < 60) "${sec}s ago" else "${sec / 60} min ago"
    }
}
